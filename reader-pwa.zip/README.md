# 📖 Leitor Simples - PWA

Aplicativo mobile PWA para simplificar e tornar acessível visualmente textos de matérias.

## ✨ Funcionalidades

- **Zona do Polegar**: Navegação e botões principais na parte inferior da tela
- **Simplificação de Textos**: Remove ruídos, URLs e formata o texto para leitura
- **Acessibilidade Visual**:
  - 4 temas de cores (Escuro, Claro, Sépia, Alto Contraste)
  - Tamanho de fonte ajustável (80% a 200%)
  - Espaçamento entre linhas configurável
  - Largura do texto ajustável
  - Fonte para dislexia
- **Leitura em Voz Alta**: Síntese de voz nativa do navegador
- **Offline**: Funciona sem internet após primeira visita
- **Gestos**: Swipe horizontal para navegar entre abas

## 🚀 Deploy no Vercel

1. Faça upload desta pasta para um repositório GitHub
2. Conecte o repositório no [Vercel](https://vercel.com)
3. Deploy automático!

Ou use a CLI:
```bash
npm i -g vercel
vercel --prod
```

## 📱 Instalação

Acesse o app no navegador do celular e toque em "Adicionar à Tela Inicial".

## 📁 Estrutura

```
reader-pwa/
├── index.html
├── manifest.json
├── sw.js
├── vercel.json
├── css/
│   └── styles.css
├── js/
│   └── app.js
└── icons/
    ├── icon-192.png
    └── icon-512.png
```
